import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vo-error-report',
  templateUrl: './vo-error-report.component.html',
  styleUrls: ['./vo-error-report.component.scss']
})
export class VoErrorReportComponent implements OnInit {

  constructor() { }
title = 'Vo Error Report';
  ngOnInit() {
  }

}
