import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daily-visit-report',
  templateUrl: './daily-visit-report.component.html',
  styleUrls: ['./daily-visit-report.component.scss']
})
export class DailyVisitReportComponent implements OnInit {
  title = 'Daily visit report';
  constructor() { }

  ngOnInit() {
  }

}
