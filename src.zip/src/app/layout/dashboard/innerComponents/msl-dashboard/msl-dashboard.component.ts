import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-msl-dashboard',
  templateUrl: './msl-dashboard.component.html',
  styleUrls: ['./msl-dashboard.component.scss']
})
export class MslDashboardComponent implements OnInit {
title = 'MSL Dashboard';
  constructor() { }

  ngOnInit() {
  }

}
