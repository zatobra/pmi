import { Component, OnInit, ViewChild } from "@angular/core";

@Component({
  selector: "app-merchandiser-attendance",
  templateUrl: "./merchandiser-attendance.component.html",
  styleUrls: ["./merchandiser-attendance.component.scss"],
})
export class MerchandiserAttendanceComponent {
  title = "Merchandiser Distribution Checkin";
}
