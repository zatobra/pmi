import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-oos-shop-list",
  templateUrl: "./oos-shop-list.component.html",
  styleUrls: ["./oos-shop-list.component.scss"],
})
export class OosShopListComponent implements OnInit {
  title = "OOS Shop List";
  constructor() {}

  ngOnInit() {}
}
