import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productivity-dashboard',
  templateUrl: './productivity-dashboard.component.html',
  styleUrls: ['./productivity-dashboard.component.scss']
})
export class ProductivityDashboardComponent implements OnInit {
  title = 'Productivity Dashboard';
  constructor() { }

  ngOnInit() {
  }

}
