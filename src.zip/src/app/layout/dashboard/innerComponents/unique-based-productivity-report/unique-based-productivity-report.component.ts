import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-unique-based-productivity-report",
  templateUrl: "./unique-based-productivity-report.component.html",
  styleUrls: ["./unique-based-productivity-report.component.scss"],
})
export class UniqueBasedProductivityReportComponent implements OnInit {
  title = "Unique Based Productivity Report";
  constructor() {}

  ngOnInit() {}
}
