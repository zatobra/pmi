import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-time-analysis-report',
  templateUrl: './time-analysis-report.component.html',
  styleUrls: ['./time-analysis-report.component.scss']
})
export class TimeAnalysisReportComponent implements OnInit {
  title = 'Time Analysis Report';
  constructor() { }

  ngOnInit() {
  }

}
