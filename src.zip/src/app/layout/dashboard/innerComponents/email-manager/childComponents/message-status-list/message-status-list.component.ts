import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'message-status-list',
  templateUrl: './message-status-list.component.html',
  styleUrls: ['./message-status-list.component.scss']
})
export class MessageStatusListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
