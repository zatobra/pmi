import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'add-edit-group',
  templateUrl: './add-edit-group.component.html',
  styleUrls: ['./add-edit-group.component.scss']
})
export class AddEditGroupComponent implements OnInit {
title="Add Edit Group"
  constructor() { }

  ngOnInit() {
  }

}
