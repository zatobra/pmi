import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attendance-report',
  templateUrl: './attendance-report.component.html',
  styleUrls: ['./attendance-report.component.scss']
})
export class AttendanceReportComponent implements OnInit {
  title='Attendance Report'
  constructor() { }

  ngOnInit() {
  }

}
