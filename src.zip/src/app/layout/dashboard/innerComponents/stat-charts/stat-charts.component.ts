import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stat-charts',
  templateUrl: './stat-charts.component.html',
  styleUrls: ['./stat-charts.component.scss']
})
export class StatChartsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
