import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-trending-oos-report",
  templateUrl: "./trending-oos-report.component.html",
  styleUrls: ["./trending-oos-report.component.scss"],
})
export class TrendingOosReportComponent implements OnInit {
  title = "Trending OOS Report";
  constructor() {}

  ngOnInit() {}
}
