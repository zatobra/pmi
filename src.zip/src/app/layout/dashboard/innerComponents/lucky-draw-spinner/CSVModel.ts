export class CSVRecord {
  public staffIdentifier: String;
  public staffName: string;
  public staffChances: String;
}