import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sos-and-sod',
  templateUrl: './sos-and-sod.component.html',
  styleUrls: ['./sos-and-sod.component.scss']
})
export class SOSandSODComponent implements OnInit {
  title = 'SOS & SOD Dashboard';
  constructor() { }

  ngOnInit() {
  }

}
