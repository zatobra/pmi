import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-complience-report",
  templateUrl: "./complience-report.component.html",
  styleUrls: ["./complience-report.component.scss"],
})
export class ComplienceReportComponent implements OnInit {
  title = "Compliance Shop List Report";
  constructor() {}

  ngOnInit() {}
}
