import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daily-evaluation-report',
  templateUrl: './daily-evaluation-report.component.html',
  styleUrls: ['./daily-evaluation-report.component.scss']
})
export class DailyEvaluationReportComponent implements OnInit {
  title = 'Daily Evaluation Report';
  constructor() { }

  ngOnInit() {
  }

}
