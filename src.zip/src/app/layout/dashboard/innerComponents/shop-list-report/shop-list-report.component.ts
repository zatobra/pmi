import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-list-report',
  templateUrl: './shop-list-report.component.html',
  styleUrls: ['./shop-list-report.component.scss']
})
export class ShopListReportComponent implements OnInit {
  title = 'Shop List Report';
  constructor() { }

  ngOnInit() {
  }

}
