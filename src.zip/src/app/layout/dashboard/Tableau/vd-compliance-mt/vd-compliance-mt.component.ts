import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vd-compliance-mt',
  templateUrl: './vd-compliance-mt.component.html',
  styleUrls: ['./vd-compliance-mt.component.scss']
})
export class VdComplianceMtComponent implements OnInit {
  type = "vd-compliance-mt";
  constructor() { }

  ngOnInit() {
  }

}
