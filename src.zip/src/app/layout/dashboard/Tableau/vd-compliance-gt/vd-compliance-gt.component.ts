import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vd-compliance-gt',
  templateUrl: './vd-compliance-gt.component.html',
  styleUrls: ['./vd-compliance-gt.component.scss']
})
export class VdComplianceGtComponent implements OnInit {
  type = "vd-compliance-gt";

  constructor() { }

  ngOnInit() {
  }

}
