import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-sss-gt-dashboard",
  templateUrl: "./sss-gt-dashboard.component.html",
  styleUrls: ["./sss-gt-dashboard.component.scss"],
})
export class SssGtDashboardComponent implements OnInit {
  type = "sss-gt-dashboard";
  constructor() {}

  ngOnInit() {}
}
