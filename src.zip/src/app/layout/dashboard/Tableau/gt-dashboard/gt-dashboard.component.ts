import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-gt-dashboard",
  templateUrl: "./gt-dashboard.component.html",
  styleUrls: ["./gt-dashboard.component.scss"],
})
export class GtDashboardComponent implements OnInit {
  type = "gt-dashboard";
  constructor() {}

  ngOnInit() {}
}
