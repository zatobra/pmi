import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-mt-dashboard",
  templateUrl: "./mt-dashboard.component.html",
  styleUrls: ["./mt-dashboard.component.scss"],
})
export class MtDashboardComponent implements OnInit {
  type = "mt-dashboard";
  constructor() {}

  ngOnInit() {}
}
