import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compliance-dashboard-national',
  templateUrl: './compliance-dashboard-national.component.html',
  styleUrls: ['./compliance-dashboard-national.component.scss']
})
export class ComplianceDashboardNationalComponent implements OnInit {
  type = "compliance-dashboard-national";
  constructor() { }

  ngOnInit() {
  }

}
