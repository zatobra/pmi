import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-tableau',
  templateUrl: './dashboard-tableau.component.html',
  styleUrls: ['./dashboard-tableau.component.scss']
})
export class DashboardTableauComponent implements OnInit {
type = 'dashboard';
  constructor() { }

  ngOnInit() {
  }

}
