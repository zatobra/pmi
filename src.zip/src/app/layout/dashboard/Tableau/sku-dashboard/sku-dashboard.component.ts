import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-sku-dashboard",
  templateUrl: "./sku-dashboard.component.html",
  styleUrls: ["./sku-dashboard.component.scss"],
})
export class SkuDashboardComponent implements OnInit {
  constructor() {}
  type = "availability-dashboard";
  ngOnInit() {}
}
